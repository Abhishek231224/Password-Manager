This is Demo of my Database Software.
//
Allow you to starting coding with Dev c++
\\
1) This is Database Software with File Handling.
2) Binary  Encrption/Decryption strings.
3) use Powershell /Batch File & System Programming For Creating this Application.
4) Searching /Sorting Data Techniques. 
5) .bat files  are lib files of program.
6) Email Functioning For Backup Data on Gmail.
7) 

What Kind of software ,We Develop ..?

1) Pharmacy Management System With File Handling.
2) Data Entry Software.
3) Password Manager. 
4) Employ Record. 
Or Any Kind of   Database Related Softwares.


Happy Programming ..!
